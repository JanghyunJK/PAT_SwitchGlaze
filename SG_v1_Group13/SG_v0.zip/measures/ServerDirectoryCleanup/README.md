

###### (Automatically generated documentation)

# Server Directory Cleanup

## Description


## Modeler Description


## Measure Type
ReportingMeasure

## Taxonomy


## Arguments


### Remove sql files from run directory

**Name:** sql,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove eso files from run directory

**Name:** eso,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove audit files from run directory

**Name:** audit,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove osm files from run directory

**Name:** osm,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove idf files from run directory

**Name:** idf,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove bnd files from run directory

**Name:** bnd,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove eio files from run directory

**Name:** eio,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove shd files from run directory

**Name:** shd,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove mdd files from run directory

**Name:** mdd,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove rdd files from run directory

**Name:** rdd,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove csv files from run directory

**Name:** csv,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Remove Sizing Run Directories files from run directory

**Name:** Sizing Run Directories,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false




