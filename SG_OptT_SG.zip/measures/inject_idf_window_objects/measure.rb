#see the URL below for information on how to write OpenStudio measures
# http://openstudio.nrel.gov/openstudio-measure-writing-guide

#see your EnergyPlus installation or the URL below for information on EnergyPlus objects
# http://apps1.eere.energy.gov/buildings/energyplus/pdfs/inputoutputreference.pdf

#see the URL below for information on using life cycle cost objects in OpenStudio
# http://openstudio.nrel.gov/openstudio-life-cycle-examples

#see the URL below for access to C++ documentation on workspace objects (click on "workspace" in the main window to view workspace objects)
# http://openstudio.nrel.gov/sites/openstudio.nrel.gov/files/nv_data/cpp_documentation_it/utilities/html/idf_page.html

$allchoices = 'All fenestration surfaces'

#start the measure
class InjectIDFWindowObjects < OpenStudio::Ruleset::WorkspaceUserScript

  # define the name that a user will see, this method may be deprecated as
  # the display name in PAT comes from the name field in measure.xml
  def name
    return " Inject IDF Window Objects"
  end

  # define the arguments that the user will input
  def arguments(workspace)
    args = OpenStudio::Ruleset::OSArgumentVector.new

    glzsys = OpenStudio::StringVector.new
    glzsys << "Baseline_ASHRAE"
    glzsys << "Baseline_GlzSys6"
    glzsys << "Baseline_GlzSys13"
    glzsys << "Baseline_GlzSys15"
    glzsys << "Baseline_GlzSys6_13"
    glzsys << "Baseline_GlzSys15_withPV"
    glzsys << "GlzSys_6_withoutPV"
    glzsys << "GlzSys_13_withoutPV"
    glzsys << "GlzSys_6_withPV"
    glzsys << "GlzSys_13_withPV"
    glzsys << "GlzSys_Dark"
    glzsys << "GlzSys_Light"
    glzsys << "GlzSys_Thermochromic_40C"
    glzsys << "GlzSys_Thermochromic_35C"
    glzsys << "GlzSys_Thermochromic_30C"
    glzsys << "FrameTest_woFrame"
    glzsys << "FrameTest_wFrame"
    glzsys << "VeryHot_ASHRAE"
    glzsys << "VeryHot_SwitchGlaze"
    glzsys << "VeryHot_Dark"
    glzsys << "VeryHot_Light"
    glzsys << "Hot_ASHRAE"
    glzsys << "Hot_SwitchGlaze"
    glzsys << "Hot_Dark"
    glzsys << "Hot_Light"
    glzsys << "Cold_ASHRAE"
    glzsys << "Cold_SwitchGlaze"
    glzsys << "Cold_Dark"
    glzsys << "Cold_Light"
    glzsys << "VeryCold_ASHRAE"
    glzsys << "VeryCold_SwitchGlaze"
    glzsys << "VeryCold_Dark"
    glzsys << "VeryCold_Light"
    
    glztype = OpenStudio::Ruleset::OSArgument::makeChoiceArgument('glztype', glzsys, true)
    glztype.setDisplayName("Choice of IGU")
    glztype.setDefaultValue("Baseline_ASHRAE")
    args << glztype
    
    thermochromic = OpenStudio::Ruleset::OSArgument::makeBoolArgument('thermochromic', false)
    thermochromic.setDisplayName('Thermochromic window?')
    thermochromic.setDefaultValue('false')
    thermochromic.setDescription('Select if glazing type has thermochromic capability')
    args << thermochromic
    
    # thermochromic window switching temperature (degree C)
    t_switching = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("t_switching", true)
    t_switching.setDisplayName("Thermochromic window switching temperature based on outermost window surface temperature")
    t_switching.setUnits("C")
    t_switching.setDefaultValue(35.0)
    args << t_switching
    
    #make choice arguments for fenestration surface
    fenestrationsurfaces = workspace.getObjectsByType("FenestrationSurface:Detailed".to_IddObjectType)
    chs = OpenStudio::StringVector.new
    fenestrationsurfaces.each do |fenestrationsurface|
      chs << fenestrationsurface.name.to_s
    end
    chs << $allchoices
    choice = OpenStudio::Ruleset::OSArgument::makeChoiceArgument('choice', chs, true)
    choice.setDisplayName("Choice of window")
    choice.setDefaultValue($allchoices)
    args << choice

    return args
  end

  # define what happens when the measure is run
  def run(workspace, runner, user_arguments)
    super(workspace, runner, user_arguments)

    #use the built-in error checking 
    if not runner.validateUserArguments(arguments(workspace), user_arguments)
      return false
    end
    
    ####################################################################################
    # assign the user inputs to variables
    ####################################################################################
    choice = runner.getStringArgumentValue('choice',user_arguments)
    glztype = runner.getStringArgumentValue('glztype',user_arguments)
    thermochromic = runner.getStringArgumentValue('thermochromic',user_arguments)
    t_switching = runner.getDoubleArgumentValue('t_switching',user_arguments)
    
    if glztype == "Baseline_ASHRAE"
      return false
    end
    
    dictionary = Hash.new
    
    # Note for setting up dictionary:
    # file names can be anything, but the name of the construction object in the idf file should match with the key of the dictionary, for this setting
    
    ####################################################################################
    # DICTIONARY FOR LOCAL SIMULATION
    ####################################################################################
    dictionary = {
      "Baseline_GlzSys6" => "C:/SpectralIDFs/GlzSys_16095-air-9_Spec.idf",
      "Baseline_GlzSys13" => "C:/SpectralIDFs/GlzSys_6374-air-3000_Spec.idf",
      "Baseline_GlzSys15" => "C:/SpectralIDFs/GlzSys_10F-air-3000_Spec.idf",
      "Baseline_GlzSys15_withPV" => "C:/SpectralIDFs/GlzSys21_13F-air-3000_Spec.idf",
      "Baseline_GlzSys6_13" => "C:/SpectralIDFs/GlzSys_16095-air-3000_Spec.idf",
      "GlzSys_6_withoutPV" => "C:/SpectralIDFs/GlzSys_10-air-9_Spec.idf",
      "GlzSys_13_withoutPV" => "C:/SpectralIDFs/GlzSys_11F-air-3000_Spec.idf",
      "GlzSys_6_withPV" => "C:/SpectralIDFs/GlzSys19_13F-air-9_Spec.idf",
      "GlzSys_13_withPV" => "C:/SpectralIDFs/GlzSys20_14F-air-3000_Spec.idf",
      "GlzSys_Dark" => "C:/SpectralIDFs/GlzSys_Dark_PV_Spec.idf",
      "GlzSys_Light" => "C:/SpectralIDFs/GlzSys_Light_PV_Spec.idf",
      "GlzSys_Thermochromic_40C" => "C:/SpectralIDFs/GlzSys_Thermochromic_40C.idf",
      "GlzSys_Thermochromic_35C" => "C:/SpectralIDFs/GlzSys_Thermochromic_35C.idf",
      "GlzSys_Thermochromic_30C" => "C:/SpectralIDFs/GlzSys_Thermochromic_30C.idf",
      "FrameTest_wFrame" => "C:/SpectralIDFs/Window_PV_frame_Spec.idf",
      "FrameTest_woFrame" => "C:/SpectralIDFs/Window_PV_No_frame_Spec_Spec.idf",
      "VeryHot_ASHRAE" => "C:/SpectralIDFs/Window_ASHRAE_zone12_Spec.idf",
      "Hot_ASHRAE" => "C:/SpectralIDFs/Window_ASHRAE_zone3_Spec.idf",
      "Cold_ASHRAE" => "C:/SpectralIDFs/Window_ASHRAE_zone456_Spec.idf",
      "VeryCold_ASHRAE" => "C:/SpectralIDFs/Window_ASHRAE_zone78_Spec.idf", 
      "VeryHot_SwitchGlaze" => "C:/SpectralIDFs/SG_zone12_Spec.idf",
      "Hot_SwitchGlaze" => "C:/SpectralIDFs/SG_zone3_Spec.idf",
      "Cold_SwitchGlaze" => "C:/SpectralIDFs/SG_zone456_Spec.idf",
      "VeryCold_SwitchGlaze" => "C:/SpectralIDFs/SG_zone78_Spec.idf",
      "VeryHot_Dark" => "C:/SpectralIDFs/dark_zone12_Spec.idf",
      "VeryHot_Light" => "C:/SpectralIDFs/light_zone12_Spec.idf",
      "Hot_Dark" => "C:/SpectralIDFs/dark_zone3_Spec.idf",
      "Hot_Light" => "C:/SpectralIDFs/light_zone3_Spec.idf", 
      "Cold_Dark" => "C:/SpectralIDFs/dark_zone456_Spec.idf",
      "Cold_Light" => "C:/SpectralIDFs/light_zone456_Spec.idf",
      "VeryCold_Dark" => "C:/SpectralIDFs/dark_zone78_Spec.idf",
      "VeryCold_Light" => "C:/SpectralIDFs/light_zone78_Spec.idf",      
    }
    
    ####################################################################################
    #DICTIONARY FOR SERVER (BRIAN'S BOX) SIMULATION
    ####################################################################################
    # dictionary = {
      # "Baseline_GlzSys6" => "../../../lib/resources/GlzSys_16095-air-9_Spec.idf",
      # "Baseline_GlzSys13" => "../../../lib/resources/GlzSys_6374-air-3000_Spec.idf",
      # "Baseline_GlzSys15" => "../../../lib/resources/GlzSys_10F-air-3000_Spec.idf",
      # "Baseline_GlzSys15_withPV" => "../../../lib/resources/GlzSys21_13F-air-3000_Spec.idf",
      # "Baseline_GlzSys6_13" => "../../../lib/resources/GlzSys_16095-air-3000_Spec.idf",
      # "GlzSys_6_withoutPV" => "../../../lib/resources/GlzSys_10-air-9_Spec.idf",
      # "GlzSys_13_withoutPV" => "../../../lib/resources/GlzSys_11F-air-3000_Spec.idf",
      # "GlzSys_6_withPV" => "../../../lib/resources/GlzSys19_13F-air-9_Spec.idf",
      # "GlzSys_13_withPV" => "../../../lib/resources/GlzSys20_14F-air-3000_Spec.idf",
      # "GlzSys_Dark" => "../../../lib/resources/GlzSys_Dark_PV_Spec.idf",
      # "GlzSys_Light" => "../../../lib/resources/GlzSys_Light_PV_Spec.idf",
      # "GlzSys_Thermochromic_40C" => "../../../lib/resources/GlzSys_Thermochromic_40C.idf",
      # "GlzSys_Thermochromic_35C" => "../../../lib/resources/GlzSys_Thermochromic_35C.idf",
      # "GlzSys_Thermochromic_30C" => "../../../lib/resources/GlzSys_Thermochromic_30C.idf",
      # "FrameTest_wFrame" => "../../../lib/resources/Window_PV_frame_Spec.idf",
      # "FrameTest_woFrame" => "../../../lib/resources/Window_PV_No_frame_Spec_Spec.idf",
    # }     

    # report initial condition
    runner.registerInitialCondition("The initial IDF file had #{workspace.objects.size} objects.")

    # load IDF
    source_idf = OpenStudio::IdfFile::load(OpenStudio::Path.new(dictionary[glztype])).get

    # add everything from the file
    workspace.addObjects(source_idf.objects)    

    runner.registerInitialCondition("Imposing fenestration construction name change on #{choice}.")
 
    ####################################################################################
    #find the fenestration surface to change
    ####################################################################################
    no_found = true
    applicable = true
    fenestrationsurfaces = workspace.getObjectsByType("FenestrationSurface:Detailed".to_IddObjectType)
    fenestrationsurfaces.each do |fenestrationsurface|
      if fenestrationsurface.getString(0).to_s.eql?(choice) || choice.eql?($allchoices)
        no_found = false
        if applicable  #skip the modeling procedure if the model is not supported
          runner.registerInfo("Changing [#{fenestrationsurface.getString(2)}] to [#{glztype}]")
          fenestrationsurface.setString(2,glztype)
          
          #fenestrationsurface.setString(6,"ASHRAE_zone78-Frame") #TODO: change this more interactively/automatically
          
        end
      end
    end
    
    ####################################################################################
    #find the thermochromic object and replace switching temperature based on input
    ####################################################################################
    if thermochromic    
      applicable = true
      tcglazings = workspace.getObjectsByType("WindowMaterial:GlazingGroup:Thermochromic".to_IddObjectType)
      tcglazings.each do |tcglazing|
        if tcglazing.getString(0).to_s.eql?("TCGlazing")
          no_found = false
          runner.registerInfo("Matching the pre-defined thermochromic object name =  #{tcglazing.getString(0)}")
          if applicable  #skip the modeling procedure if the model is not supported
            runner.registerInfo("Changing thermochromic switching temperature to #{t_switching}C")
            tcglazing.setString(1,(t_switching-0.5).to_s)
            tcglazing.setString(3,(t_switching).to_s)
                      
          end
        end
      end
    end
    
    ####################################################################################
    #give an error for the name if no surface is changed
    ####################################################################################
    if no_found
      runner.registerError("Measure #{name} cannot find #{choice}. Exiting......")
      return false
    elsif applicable
      # report final condition of workspace
      runner.registerFinalCondition("Imposed fenestration construction name change on #{choice}.")
    else
      runner.registerAsNotApplicable("#{name} is not running for #{choice} because of inapplicability. Skipping......")
    end
    
    # report final condition
    runner.registerFinalCondition("The final IDF file had #{workspace.objects.size} objects.")

    return true

  end

end

#this allows the measure to be use by the application
InjectIDFWindowObjects.new.registerWithApplication